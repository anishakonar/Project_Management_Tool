
<!-- <div class="container mt-5">
          <div class="col-md-10">
              <img src="home.png" class="img-fluid" alt="Home Image">
          </div>
        </div> -->
      <main></main>
      <!-- Footer Section -->
      <footer>
        <p>&copy; Alok Kumar <?php echo date('y')?> | Email: ak0914850@gmail.com | Address: Tezpur University, Tezpur, Assam, 784028</p>
        <p>About: Currently pursuing MCA from Tezpur University, Assam, done BCA from Dr. Shyama Prasad Mukherjee University, Jharkhand Ranchi</p>
      </footer>
      
      <!-- Bootstrap JS -->
      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </body>
  </html>